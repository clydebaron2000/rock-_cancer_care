import React, { Component } from 'react';
import Form from '../../global-components/Form'
import '../../css/form.css';
function PatientIntakeForm () {
	return (
        <div className="form-page-body">
            <Form isOpen={true}/>
        </div>
	)
}
export default PatientIntakeForm