import React, { Component } from 'react';
import '../../css/main.css';
function HomePage () {
	return (
		<div>
			<div>
				HI everybody
			</div>
		</div>
	)
}
export default HomePage