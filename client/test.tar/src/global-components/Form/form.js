export const form=[{
    "first":,
    "last":,
    "address":{
        "street address":,
        "city":,
        "state/province/region":,
        "zip/postalcode":,
    },
    "birth date":,
    "gender":,// m/f
    "phone":,
    "email":,
},{
    services:

    Cancer Buddy

    Education and Awareness
    
    Grocery Shopping (using your funds)
    
    Hospital Visitation
    
    Meal Delivery
    
    Peer Support for Survivors
    
    Prayer & Spiritual Support
    
    Support Group
    
    Not sure yet

    cards of encouragement for a cancer patient

    devotionals and books of encouragement for self or cancer patient    

    ookies for encouragement for self or a cancer patient
}
terms and conditions:
i agree

do you need a financial assistant

If "yes" the same thank you message appears at end of the intake form when done applying for "Services" along with a link to the Financial Assistance application

]
APPLICATION 2

Type of Financial Assistance applying for : Grocery gift card, Utility assistance, gas card, pharmacy card, rental assistance, clothing, bus pass, food from food pantry, meals while recovering from Chemotherapy, surgery or radiation.  
3. Please explain your hardship and how financial assistance will lift your burden and help you? 100 to 200 words? Be detailed.
4.How will receiving financial assistance allow you to focus on healing instead of being worried about financial burdens? min 100 to 200 words be detailed
. Applicant Signature   Date

To be completed by Physician, Nurse or Social worker only. All information is mandatory. Physicians will be contacted to receive financial assistance.

Medical Information ...below this is the part where a doctor would fill out to confirm a person has cancer. (picture show Jack)

Thank you for your application. A Rock Cancer C.A.R.E. Ministry (RCC) Leader will review this application and contact the applicant. Funds are limited and based on availability. All information is strictly confidential and is intended for RCC use only except as noted in the applicant acknowledgment section.