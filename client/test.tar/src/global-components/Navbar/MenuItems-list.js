// ensure this is similar to file structure
export const MenuItems = [{
  title: 'Home',
  url: '/',
  style: 'underline'
}, {
  title: 'About Us',
  url: '/about-s',
  style: 'underline'
}, {
  title: 'Patient Assistantance',
  url: '/pattient-assistance',
  style: 'underline'
}, {
  title: 'Volunteer',
  url: '/volunteer',
  style: 'underline'
}]